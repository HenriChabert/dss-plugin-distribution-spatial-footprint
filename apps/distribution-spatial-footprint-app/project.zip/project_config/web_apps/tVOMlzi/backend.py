import dataiku
import pandas as pd
import numpy as np
import json
from ast import literal_eval
import flask
from flask import request
from geomatic.geographic_handling import read_geo_point, compute_geo_points_collection_center
import time  

start_time = time.time()
# Loading the locations_competition dataset :
locations_competition_df = dataiku.Dataset("locations_competition").get_dataframe()
locations_competition_df = locations_competition_df[~locations_competition_df["distance_between_locations"].isnull()]
locations_competition_df = locations_competition_df.reset_index()
location_1 = locations_competition_df["location_identifier"][0]
location_2 = locations_competition_df["in_isochrone_location_identifier"][0]
print("location 1 : {} | location 2 : {}".format(location_1, location_2))

# Variables definition : 
project_key = dataiku.get_custom_variables()["projectKey"]
client = dataiku.api_client()
project = client.get_project(project_key)
variables = project.get_variables()["standard"]
isochrones_range_min = variables["isochrones_range_min"]
isochrones_labels = ["isochrone_{}_min".format(isochrone) \
                     for isochrone in isochrones_range_min]
print("BACKEND_LOG_MESSAGE : isochrones_labels : {}".format(isochrones_labels))
analyze_pois = variables["analyze_pois"]
analyze_customers = variables["analyze_customers"]

# Loading locations data :
locations_isochrones_df = dataiku.Dataset("locations_isochrones").get_dataframe()
dataframe_columns = locations_isochrones_df.columns
application_filtering_columns = [col for col in dataframe_columns if \
                                 ((col not in isochrones_labels) and \
                                  (col not in ["latitude", "longitude", "geo_point"]) and \
                                  (col!="location_identifier")
                                 )]
print("BACKEND_LOG_MESSAGE : application_columns : {}".format(application_filtering_columns))
#columns_unique_values = {col:list(np.unique(locations_isochrones_df[col]))\
#                                     for col in dataframe_columns}

locations_identifiers = list(locations_isochrones_df["location_identifier"])
locations_geo_points = list(locations_isochrones_df["geo_point"])
locations_geo_points = {location:read_geo_point(geo_point) \
                        for location, geo_point in zip(locations_identifiers, locations_geo_points)}
locations_data = {location:{} for location in locations_identifiers}

# Loading locations POI's data :
if analyze_pois:
    points_of_interest_tags = variables["points_of_interest_tags"]
    points_of_interest_enrichments = variables["points_of_interest_enrichments"]
    points_of_interest_all_tags = points_of_interest_tags+points_of_interest_enrichments
    try:
        locations_pois_df = dataiku.Dataset("locations_points_of_interest").get_dataframe()
        unique_pois_df = dataiku.Dataset("unique_points_of_interest").get_dataframe()
        points_of_interest_computed = True
    except:
        points_of_interest_computed = False
        
    if points_of_interest_computed:
        pois_ids = list(unique_pois_df["poi_id"])
        poi_attributes = {poi_id:{} for poi_id in pois_ids}

        for poi_data in unique_pois_df.itertuples():
            poi_id = poi_data.poi_id
            poi_attributes[poi_id]["coordinates"] = [poi_data.poi_lon, poi_data.poi_lat]
            poi_attributes[poi_id]["poi_all_information"] = poi_data.tags
            poi_attributes[poi_id]["poi_tag_types"] = []
            poi_attributes[poi_id]["poi_tags"] = []

            for tag_type in points_of_interest_all_tags:
                poi_has_tag_type = not pd.isnull(getattr(poi_data, tag_type))
                if poi_has_tag_type:
                    poi_attributes[poi_id]["poi_tag_types"].append(tag_type)
                    poi_attributes[poi_id]["poi_tags"].append(getattr(poi_data, tag_type))

# Loading locations customers data :
if analyze_customers:
    try:
        customers_df = dataiku.Dataset("customers_prepared").get_dataframe()
        locations_customers_df = dataiku.Dataset("locations_customers").get_dataframe()
        customers_computed = True
    except:
        customers_computed = False
    
    if customers_computed:
        customers_geo_points = {customer:read_geo_point(geo_point) \
                                for customer, geo_point \
                                in zip(customers_df["customer_id"], customers_df["geo_point"])}
    
    
    
                
# Computing backend data :
for isochrone_type in isochrones_labels:
    focus_isochrones = list(locations_isochrones_df[isochrone_type])    
    
    for location, isochrone_geojson in zip(locations_identifiers, focus_isochrones):
        locations_data[location][isochrone_type] = {}
        locations_data[location][isochrone_type]["isochrone_geojson"] = literal_eval(isochrone_geojson)
        
        # POI's :
        if analyze_pois and points_of_interest_computed:
            sampled_locations_pois_df = locations_pois_df[(locations_pois_df["isochrone_type"]==isochrone_type) & (locations_pois_df["poi_belonging_location"]==location)]
            location_isochrone_pois = list(sampled_locations_pois_df["poi_belonging_location"])
            locations_data[location][isochrone_type]["pois_list"] = location_isochrone_pois
        
        # Customers : 
        if analyze_customers and customers_computed:
            sampled_locations_customers_df = locations_customers_df[(locations_customers_df["isochrone_type"]==isochrone_type) & (locations_customers_df["location_identifier"]==location)]
            location_isochrone_customers = list(sampled_locations_customers_df["included_customer_id"])
            locations_data[location][isochrone_type]["customers_list"] = location_isochrone_customers
    
    
# Dataframes deletion : 
del locations_isochrones_df
del locations_competition_df
if analyze_pois and points_of_interest_computed:
    del unique_pois_df
    del locations_pois_df
    del sampled_locations_pois_df
if analyze_customers and customers_computed:
    del customers_df
    del locations_customers_df
    del sampled_locations_customers_df



print("BACKEND_LOG_MESSAGE | All parameters loaded in {} seconds".format(time.time() - start_time))

# Backend functions : 
@app.route("/send_location_data/", methods=["POST"])
def send_location_data():
    params = request.get_json(force=True)
    geojsons_collection = []
    geojsons_collection_colors = []
    selected_locations_geo_points = []
    customers_locations_geo_points = []
    focus_on_a_location = params["focus_on_a_location"]
    location_to_focus_on = params["location_to_focus_on"]
    isochrones_colors = params["isochrones_colors"]
    isochrones_to_display = params["isochrones_to_display"]
    
    for isochrone_type in reversed(isochrones_labels):
        if isochrone_type in isochrones_to_display:
            if focus_on_a_location:
                selected_locations_geo_points.append(locations_geo_points[location_to_focus_on])
                geojsons_collection.append(locations_data[location_to_focus_on][isochrone_type]["isochrone_geojson"])
                geojsons_collection_colors.append(isochrones_colors[isochrone_type])

                if analyze_customers and customers_computed:
                    isochrone_customers = locations_data[location_to_focus_on][isochrone_type]["customers_list"]
                    for customer in isochrone_customers:
                        customers_locations_geo_points.append(customers_geo_points[customer])
                
            else:
                for location in locations_identifiers:
                    selected_locations_geo_points.append(locations_geo_points[location])
                    geojsons_collection.append(locations_data[location][isochrone_type]["isochrone_geojson"])
                    geojsons_collection_colors.append(isochrones_colors[isochrone_type])
                    
                    if analyze_customers and customers_computed:
                        isochrone_customers = locations_data[location][isochrone_type]["customers_list"]
                        for customer in isochrone_customers:
                            customers_locations_geo_points.append(customers_geo_points[customer])
    
    map_new_center = compute_geo_points_collection_center(selected_locations_geo_points)
    print("BACKEND_LOG_MESSAGE | Sending data to the front")
    return json.dumps({"status": 200,
                       "geojsons_collection":geojsons_collection,
                       "geojsons_collection_colors":geojsons_collection_colors,
                       "locations_geo_points":selected_locations_geo_points,
                       "customers_locations_geo_points":customers_locations_geo_points,
                       "map_new_center":map_new_center
                      })

@app.route('/send_parameters_to_front/')
def send_parameters_to_front():
    return json.dumps({"status": 200,
                       "isochrones_labels":isochrones_labels,
                       "application_filtering_columns":application_filtering_columns,
                       #"columns_unique_values":columns_unique_values,
                       "locations_identifiers":locations_identifiers,
                       "locations_data":locations_data,
                       #"poi_attributes":poi_attributes
                      })

@app.route('/dummy_intersection/', methods=["POST"])
def dummy_intersection():
    params = request.get_json(force=True)
    isochrone_type = params["isochrones_to_display"][0]
    geojson_1 = locations_data[location_1][isochrone_type]["isochrone_geojson"]
    geojson_2 = locations_data[location_2][isochrone_type]["isochrone_geojson"]
    return json.dumps({"status": 200,
                       "geojson":geojson_1,
                       "geojson_2":geojson_2
                      })
@app.route('/compute_relevant_pois/<path:params>')
def compute_relevant_pois(params):
    return ''
