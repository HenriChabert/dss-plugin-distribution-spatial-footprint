/*
First tests add column-based filters :
$('.ui.multiple.dropdown')
  .dropdown({
    maxSelections: 10
  })
;
*/
// Loading HTML parameters :
let parameters_container = document.getElementById("parameters_container");
let div_focus_location = document.getElementById("locations_to_focus_on");
let checkbox_focus_location = document.getElementById("checkbox_focus_location");
let selector_focus_location = document.getElementById("focus_location");
let selector_isochrone_type = document.getElementById("isochrone_type");
let checkbox_customers = document.getElementById("checkbox_customers");
let selector_analysis = document.getElementById("selector_analysis");
let selector_isochrones_strategy = document.getElementById("selector_isochrones_strategy");
let single_isochrone_strategy = document.getElementById("single_isochrone_strategy");
let multiple_isochrones_strategy = document.getElementById("multiple_isochrones_strategy");
let multiple_isochrones_strategy_divs = multiple_isochrones_strategy.getElementsByTagName('div');
let input_single_isochrone_color = document.getElementById("single_isochrone_color");

/*
First tests add column-based filters :
let columns_selector = document.getElementById("columns_selector");
let columns_values_container = document.getElementById("columns_values_container")
columns_values_container.style.display = 'none';
let columns_values_selector = document.getElementById("columns_values_selector")
*/


function getHTMLCollectionNames(html_collection){
    html_collection_names = [];
    for (var i = 0; i < html_collection.length; i++) {
        html_collection_names.push(html_collection[i].name);    
    }
    return html_collection_names;
}

function getHTMLInputValue(html_input_id){
    html_input = document.getElementById(html_input_id);
    html_input_value = html_input.value;
    return html_input_value;
}

function loadIsochronesParameters(){
    isochrones_parameters = {};
    isochrones_to_display = [];
    isochrones_colors = {};    
    
    if (isochronesStrategyIsSingle()){
        isochrone_type = selector_isochrone_type.value;
        isochrones_to_display.push(isochrone_type);
        isochrones_colors[isochrone_type] = input_single_isochrone_color.value;
        console.log(`FRONT_LOG_MESSAGE | Isochrone focus '${isochrone_type}' | Color : ${input_single_isochrone_color.value}`);
    }
    
    else {
        multiple_isochrones_names = getHTMLCollectionNames(multiple_isochrones_strategy_divs); 
        multiple_isochrones_names.forEach(function(item, index) {
            
            isochrone_checkbox = document.getElementById(`${item}_checkbox`);
            isochrone_checkbox_is_checked = isochrone_checkbox.checked
            if (isochrone_checkbox_is_checked){
                isochrones_to_display.push(`${item}`)
            }
            
            isochrone_color = getHTMLInputValue(`${item}_color`);
            console.log(`FRONT_LOG_MESSAGE | Isochrone '${item}' | Selected : ${isochrone_checkbox_is_checked} | Color : ${isochrone_color}`);
            isochrones_colors[`${item}`] = isochrone_color;
        })
    }
    
    console.log(`FRONT_LOG_MESSAGE | Isochrones to display are : ${isochrones_to_display}`); 
    console.log(`FRONT_LOG_MESSAGE | Isochrones colors loaded are : ${JSON.stringify(isochrones_colors)}`);
    isochrones_parameters["isochrones_to_display"] = isochrones_to_display
    isochrones_parameters["isochrones_colors"] = isochrones_colors
    return isochrones_parameters;
}



// Events :
parameters_container.onchange = function(){
    loadFrontendParameters();   
};

/*
First tests add column-based filters :
columns_selector.onchange = function(){
    switchFilteringColumnsDisplay();
};
*/
checkbox_focus_location.onchange = function(){
    switchLocationsDisplay();   
};
selector_isochrones_strategy.onchange = function(){
    switchIsochronesDisplay();   
};

// Creating map options
let mapOptions = {
    center: [47.3013485, 5.016175695243367],
    zoom: 8
}

// Creating a map object
let map = new L.map('map', mapOptions);
let layer = new L.TileLayer('http://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png')         
// Adding layer to the map
map.addLayer(layer);
let map_layers = new L.LayerGroup();
map_layers.addTo(map);

// Initial script :

loadBackendParameters()
switchLocationsDisplay()
switchIsochronesDisplay()


function selectIsEmpty(select) {
    let result = [];
    let options = select && select.options;
    let opt;
    
    for (let i=0, iLen=options.length; i<iLen; i++) {
        opt = options[i];
        if (opt.selected) {
            result.push(opt.value || opt.text);
        }
    }
    if (result.length >0){
        return false
    }
    else {
        return true
    }
};


// Return an array of the selected opion values
// select is an HTML select element
function getSelectValues(select) {
  let result = [];
  let options = select && select.options;
  let opt;

  for (let i=0, iLen=options.length; i<iLen; i++) {
    opt = options[i];

    if (opt.selected) {
      result.push(opt.value || opt.text);
    }
  }
  return result;
}

// Events functions :
function loadFrontendParameters(){
    focus_on_a_location = checkbox_focus_location.checked
    display_customers = checkbox_customers.checked    
    location_to_focus_on = selector_focus_location.value
    
    
    isochrones_parameters = loadIsochronesParameters()
    isochrones_to_display = isochrones_parameters["isochrones_to_display"]
    isochrones_colors = isochrones_parameters["isochrones_colors"]
    
    
    console.log(`FRONT_LOG_MESSAGE | New location : ${location_to_focus_on}`);
    
    parameters = {
        "focus_on_a_location": focus_on_a_location,
        "display_customers": display_customers,
        "location_to_focus_on": location_to_focus_on,
        "isochrones_to_display": isochrones_to_display,
        "isochrones_colors": isochrones_colors
    }
    console.log(`FRONT_LOG_MESSAGE | Query parameters : ${JSON.stringify(parameters)}`); 
    console.log(JSON.parse(JSON.stringify(parameters)))
    
    
    //TODO : later on, the frontend parameters should be loaded after checking 'selector_analysis.value'
    analysis_type = selector_analysis.value
    if (analysis_type=="isochrones_properties"){
        loadLocationData(parameters); 
    }
    else{
        displayDummyIntersection(parameters);
    }  
};

// Display functions :
function switchIsochronesDisplay(){
    if (isochronesStrategyIsSingle()){
        single_isochrone_strategy.style.display = 'block';
        multiple_isochrones_strategy.style.display = 'none';
    }
    else {
        multiple_isochrones_strategy.style.display = 'block';
        single_isochrone_strategy.style.display = 'none';
    }
}

function isochronesStrategyIsSingle(){
    isochrones_strategy = selector_isochrones_strategy.value
    console.log(`FRONT_LOG_MESSAGE | Isochrones strategy is now : ${isochrones_strategy}`);
     if (isochrones_strategy=="single_isochrone"){
        return true 
    }
    else {
        return false
    }
};

function switchLocationsDisplay(){
    checkbox_focus_location_checked = checkbox_focus_location.checked
    console.log(`FRONT_LOG_MESSAGE | location checkbox is now : ${checkbox_focus_location_checked}`);
    if (checkbox_focus_location_checked){
        div_focus_location.style.display = 'block';
    }
    else{
        div_focus_location.style.display = 'none';
    }
}

/*
First tests add column-based filters :
function switchFilteringColumnsDisplay(){
    //removeOptions(columns_values_selector)
    
    if(selectIsEmpty(columns_selector)){
        columns_values_container.style.display = 'none';
        columns_values_container.innerHTML = "";
    }
    
    else {
        columns_values_container.style.display = 'block';
        columns_values_container.innerHTML = "";
        $.getJSON(
            getWebAppBackendUrl('send_parameters_to_front'+'/'),
                  function(backend_response){
            columns_unique_values = backend_response["columns_unique_values"]
            
            columns_selection = getSelectValues(columns_selector);
            //enrich_html_select(application_filtering_columns, "columns_selector", "option")
            columns_selection.forEach(function(item, index){
                let ui_container = document.createElement("div");
                //ui_container.classList.add("ui", "fluid", "multiple", "selection", "dropdown")
                ui_container.classList.add("ui", "container")
                ui_container.id = `${item}_ui_container`;
                //ui_container.name = `${item}_values_container`;
                
                //
                //ui_container.class = "ui container"
                
                let ui_fluid_multiple_selection_dropdown = document.createElement("div");
                ui_fluid_multiple_selection_dropdown.classList.add("ui", "fluid", "multiple", "selection", "dropdown")
                ui_fluid_multiple_selection_dropdown.id = `${item}_ui_fluid_multiple_selection_dropdown`;
                ui_fluid_multiple_selection_dropdown.tabindex=0
                
                column_possible_values = columns_unique_values[`${item}`] ; // TODO;
                let tmp_select = document.createElement("select");
                //tmp_select.classList.add("ui", "fluid", "multiple", "selection", "dropdown")
                tmp_select.id = `${item}_values`;
                //tmp_select.name = `${item}_values`;
                tmp_select.setAttribute("multiple", true);
                
                tmp_select.class = "ui fluid multiple selection dropdown";
                
                ui_fluid_multiple_selection_dropdown.appendChild(tmp_select)
                ui_container.appendChild(ui_fluid_multiple_selection_dropdown);
                columns_values_container.appendChild(ui_container);
                enrich_html_select(column_possible_values, `${item}_values`, "option");
                
            })}
                      )
        
        
        
    }
}
*/


function enrich_html_select(list_of_options,
                             html_parent_id,
                             child_html_type){
    console.log(`Enriching HTML element '${html_parent_id}'`)
    let html_element = document.getElementById(html_parent_id)
    list_of_options.forEach(function(item, index) {
        let option = document.createElement(child_html_type);
        option.text = `${item}`;
        html_element.add(option);
    });
}

function loadMultipleIsochronesDisplay(isochrone_focus){
    let isochrone_focus_div = document.createElement("div");
    isochrone_focus_div.id = `${isochrone_focus}_parameters`;
    isochrone_focus_div.name = `${isochrone_focus}`;
    isochrone_focus_div.class = `isochrone_focus`

    let isochrone_focus_checkbox_label = document.createElement('label');
    isochrone_focus_checkbox_label.innerHTML = `${isochrone_focus}`;
    isochrone_focus_div.appendChild(isochrone_focus_checkbox_label);

    let isochrone_focus_checkbox = document.createElement("input");
    isochrone_focus_checkbox.type="checkbox";
    isochrone_focus_checkbox.name=`${isochrone_focus}_checkbox`;
    isochrone_focus_checkbox.id=`${isochrone_focus}_checkbox`;
    isochrone_focus_div.appendChild(isochrone_focus_checkbox);

    let isochrone_focus_color = document.createElement("input");
    isochrone_focus_color.type="color";
    isochrone_focus_color.name=`${isochrone_focus}_color`;
    isochrone_focus_color.id=`${isochrone_focus}_color`;
    isochrone_focus_color.value = "#F41515";
    isochrone_focus_div.appendChild(isochrone_focus_color);
    multiple_isochrones_strategy.appendChild(isochrone_focus_div);
};

function filterAvailableLocations(){
    filtering_columns_selected = getSelectValues(filtering_columns);
    
}

function loadBackendParameters(){
    $.getJSON(getWebAppBackendUrl('send_parameters_to_front'+'/'),
        function(backend_response){
        application_filtering_columns = backend_response["application_filtering_columns"]
        //First tests add column-based filters :
        //enrich_html_select(application_filtering_columns, "columns_selector", "option")
        isochrones_labels = backend_response["isochrones_labels"]
        isochrones_labels.forEach(function(item, index) {
            loadMultipleIsochronesDisplay(item) 
        });
        enrich_html_select(isochrones_labels, "isochrone_type", "option")
        locations = backend_response["locations_identifiers"]
        enrich_html_select(locations, "focus_location", "option")
    }
             )
}

function removeOptions(select_element) {
   let i, L = select_element.options.length - 1;
   for(i = L; i >= 0; i--) {
      select_element.remove(i);
   }
}


// Map functions : 
function onEachFeature(feature, layer) {
    if (feature.properties && feature.properties.popupContent) {
        layer.bindPopup(feature.properties.popupContent);
    }
}

function loadLocationData(parameters){
    $.ajax({
        type: "POST",
        method: "POST",
        url: getWebAppBackendUrl('send_location_data')+'/',
        data: JSON.stringify(parameters),
        dataType:"json",
        success: function(backend_response){
            geojsons_collection = backend_response["geojsons_collection"]
            let n_geojsons = geojsons_collection.length;
            geojsons_collection_colors = backend_response["geojsons_collection_colors"]
            locations_geo_points = backend_response["locations_geo_points"]
            customers_locations_geo_points = backend_response["customers_locations_geo_points"]
            let n_customers = customers_locations_geo_points.length;
            map_new_center = backend_response["map_new_center"]
            
            map_layers.clearLayers()
            for (let index_ = 0; index_ < n_geojsons; index_++) {
                geojson = L.geoJson(geojsons_collection[index_], {
                    style: {
                        "color": geojsons_collection_colors[index_],
                        "weight": 5,
                        "opacity": 0.65},
                    onEachFeature: onEachFeature
                });
          
                
                map_layers.addLayer(geojson);
                geo_point_lon = locations_geo_points[index_][0]
                geo_point_lat = locations_geo_points[index_][1]
                /*let shop_marker = L.AwesomeMarkers.icon({
                    markerColor: "#000000" "#FFFFFF"
                });*/
                marker = L.marker([geo_point_lat, geo_point_lon], {icon: L.AwesomeMarkers.icon({icon: 'shopping-cart', prefix: 'fa', markerColor: "#000000"})});
                map_layers.addLayer(marker);
            }
            if (checkbox_customers.checked){
                for(let index_ = 0; index_ < n_customers; index_++){
                    //console.log(`marker : ${customers_locations_geo_points[index_]}`);
                    geo_point_lon = customers_locations_geo_points[index_][0]
                    geo_point_lat = customers_locations_geo_points[index_][1]
                    marker = L.marker([geo_point_lat, geo_point_lon]);
                    map_layers.addLayer(marker);
                }
                }
            map.panTo(new L.LatLng(map_new_center[1], map_new_center[0]));
    }});
}

let myStyle_red = {"color": "red", "weight": 5, "opacity": 0.65};
let myStyle_blue = {"color": "blue", "weight": 5, "opacity": 0.65};
let myStyle_violet = {"color": "violet", "weight": 5, "opacity": 0.65};

function displayDummyIntersection(parameters){
    
    $.ajax({
        type: "POST",
        method: "POST",
        url: getWebAppBackendUrl('dummy_intersection')+'/',
        data: JSON.stringify(parameters),
        dataType:"json",
        success: function(backend_response){
            let geojsonFeature = backend_response["geojson"]
            let geojsonFeature_2 = backend_response["geojson_2"]
            console.log('geojsonFeature :')
            console.log(geojsonFeature);
            console.log();
            map_layers.clearLayers()
            let intersection = turf.intersect(geojsonFeature, geojsonFeature_2);
            geojson = L.geoJson(geojsonFeature, {style: myStyle_red})
            geojson_2 = L.geoJson(geojsonFeature_2, {style: myStyle_blue});
            gejoson_intersection = L.geoJson(intersection, {style: myStyle_violet});
            map_layers.addLayer(geojson)
            map_layers.addLayer(geojson_2)
            map_layers.addLayer(gejoson_intersection)
            
    }});
};
