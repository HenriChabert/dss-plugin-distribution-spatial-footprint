import re
from ast import literal_eval
import shapely
from shapely.geometry import Point, Polygon
import geopy.distance
import numpy as np

def read_wkt_geo_point(geo_point):
    geo_point = re.sub("POINT {0,1}|\(|\)","", geo_point)
    geo_point = geo_point.split(" ")
    geo_point = [float(coordinate) for coordinate in geo_point]
    geo_point = tuple(geo_point)
    return geo_point

def create_wkt_geo_point(latitude, longitude):
    return "POINT({} {})".format(longitude, latitude)
    
def read_geo_point(geo_point):
    geo_point = str(geo_point)
    try:
        if 'point' in str(geo_point).lower():
            geo_point = read_wkt_geo_point(geo_point)
        else:
            geo_point = literal_eval(geo_point)
        return geo_point
    except ValueError:
        return 'ValueError : geo_point is not readable'

def read_as_shapely_polygon(polygon):
    if not isinstance(polygon, shapely.geometry.polygon.Polygon):
        polygon = Polygon(polygon)
    return polygon

def geo_point_is_in_geojson(geo_point, geojson):
    shapely_point = Point(geo_point)
    shapely_geometry = Polygon(geojson["geometry"]["coordinates"][0])
    point_in_geojson = shapely_point.within(shapely_geometry)
    return point_in_geojson

def polygon_contains_geo_point(geometry_polygon, geo_point):
    shapely_geometry = Polygon(geometry_polygon)
    shapely_point = Point(geo_point)
    polygon_contains_point = shapely_geometry.contains(shapely_point)
    return polygon_contains_point

def compute_polygon_envelope(polygon):
    polygon = Polygon(polygon)
    envelope = polygon.envelope
    longitudes, latitudes = envelope.exterior.coords.xy

    envelope_data = {"min_lat":np.min(latitudes),
                     "min_lon":np.min(longitudes),
                     "max_lat":np.max(latitudes),
                     "max_lon":np.max(longitudes)}

    envelope_data_str = "({},{},{},{})".format(envelope_data["min_lat"],
                                               envelope_data["min_lon"],
                                               envelope_data["max_lat"],
                                               envelope_data["max_lon"]
                                              )
    return envelope_data, envelope_data_str

def compute_geo_points_collection_center(geo_points_collection):
    """
    geo points formats :
    - (longitude, latitude)
    - [longitude, latitude]
    """
    n_geo_points = len(geo_points_collection)
    longitudes = []
    latitudes = []
    for geo_point in geo_points_collection:
        longitudes.append(geo_point[0])
        latitudes.append(geo_point[1])
        
    geo_points_center = [np.mean(longitudes), np.mean(latitudes)]
    return geo_points_center


def compute_geodesic_distance(geo_point_1, geo_point_2, reverse_coordinates):
    """
    geo_point_1, geo_point_2 formats :
    - (latitude, longitude)
    - [latitude, longitude]

    --> distance in km
    """
    try:
        if reverse_coordinates:
            distance = geopy.distance.distance(reverse_geo_point_coordinates(geo_point_1), reverse_geo_point_coordinates(geo_point_2)).km
        else:
            distance = geopy.distance.distance(geo_point_1, geo_point_2).km
        return distance
    
    except:
        return None
    pass

def reverse_geo_point_coordinates(geo_point):
    """
    geo_point : 'tuple' or list 
    """
    return [geo_point[1], geo_point[0]]

def reverse_polygon_coordinates(polygon):
    """
    polygon must have format :
    [[param_1_1, param_2_1], [param_1_2, param_2_2], ...., [param_1_n, param_2_n]]
    """
    new_coordinates = [reverse_geo_point_coordinates(coordinates) for coordinates in polygon]
    return new_coordinates

def from_polygon_coordinates_to_overpass_geometry(polygon):
    """
    polygon must have format :
    [[longitude_1, latitude_1], [longitude_2, latitude_2], ...., [longitude_n, latitude_n]]
    """
    polygon = reverse_polygon_coordinates(polygon)
    overpass_parameters = str(polygon)
    overpass_parameters = re.sub("[\[\],]", "", overpass_parameters)
    overpass_parameters = '(poly:"{}")'.format(overpass_parameters)
    return overpass_parameters