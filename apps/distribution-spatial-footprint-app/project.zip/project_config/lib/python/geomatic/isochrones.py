import numpy as np
import openrouteservice as ors
from .utils import from_minutes_to_seconds, AVAILABLE_ISOCHRONES_APIS

class isochronesManager():

    def __init__(self, isochrones_api_to_use, api_key, isochrones_api_parameters, isochrones_range_min):

        self.isochrones_api_to_use = isochrones_api_to_use
        self.api_key = api_key
        self.isochrones_range_min = isochrones_range_min
        self.isochrones_range_sec = []
        self.isochrones_api_parameters = isochrones_api_parameters
        self.isochrones_attributes = self.isochrones_api_parameters["isochrones_attributes"]
        self.load_params()
        self.client = self.generate_api_client()
    
    def load_params(self):
        for minute_val in self.isochrones_range_min:
            self.isochrones_range_sec.append(from_minutes_to_seconds(minute_val))
        if not self.isochrones_api_to_use in AVAILABLE_ISOCHRONES_APIS:
            message = "Isochrone api '{}' use is not implemented !"
            raise Exception(message)

    def generate_api_client(self):
        api_key = self.api_key
        if self.isochrones_api_to_use == 'open_route_service':
            client = ors.Client(key=api_key,
                                base_url="https://api.openrouteservice.org",
                                timeout=60,
                                retry_timeout=60)
        return client

    def prepare_coordinates_for_query(self, coordinates):
        final_coordinates = []
        n_coordinates = len(coordinates)
        if self.isochrones_api_to_use == 'open_route_service':
            # OpenRouteService allows to query 5 couple of coordinates per query : hence we split the original list
            # in a list of lists, each containing 5 coordinates couples
            tmp_coordinates = []

            for index, couple in enumerate(coordinates):
                last_index = (index == n_coordinates-1)
                if index !=0 :
                    if (index)%5 == 0:
                        final_coordinates.append(tmp_coordinates)
                        tmp_coordinates = []
                tmp_coordinates.append(couple)
                if last_index:
                    final_coordinates.append(tmp_coordinates)
                    tmp_coordinates = []
        
        return final_coordinates
    
    def rename_isochrones_features_keys(self, isochrone_type):
        if self.isochrones_api_to_use == 'open_route_service':
            return "isochrone_{}_sec".format(isochrone_type)
    
    def compute_isochrones_features(self, latitudes, longitudes):
        transportation_mode = self.isochrones_api_parameters["transportation_mode"]
        range_seconds = self.isochrones_range_sec
        n_isochrones = len(range_seconds)
        isochrones_indexes = range(n_isochrones)

        isochrones_features = {isochrone_type:[] for isochrone_type in self.isochrones_range_min}
        isochrones_indexes_labels = {isochrone_index:minute_val\
                                   for isochrone_index, minute_val in
                                   zip(isochrones_indexes, self.isochrones_range_min)}

        if self.isochrones_api_to_use == 'open_route_service':
            coordinates = [[longitude, latitude] for latitude, longitude in zip(latitudes, longitudes)]
            final_coordinates = self.prepare_coordinates_for_query(coordinates)
            n_ensemble_of_coordinates = len(final_coordinates)

            for index, coordinates_ensemble in enumerate(final_coordinates):
                print("querying ensemble of coordinates {} / {} | transportation_mode : {} "\
                      .format(index+1, n_ensemble_of_coordinates, transportation_mode))
                isochrones = self.client.isochrones(locations=coordinates_ensemble,
                                                    range_type='time',
                                                    units='km',
                                                    profile=transportation_mode,
                                                    range=range_seconds,
                                                    attributes=self.isochrones_attributes)
                size_coordinates_ensemble = len(coordinates_ensemble)
                isochrones = np.array(isochrones["features"]).reshape(size_coordinates_ensemble, n_isochrones)
                for isochrone_index in isochrones_indexes:
                    isochrone_type = isochrones_indexes_labels[isochrone_index]
                    focus_isochrones = isochrones[:,isochrone_index]
                    isochrones_features[isochrone_type]+= list(focus_isochrones)
            return isochrones_features

    def extract_isochrone_attributes(self, isochrone_geojson):
        if self.isochrones_api_to_use == 'open_route_service':
            return {isochrone_attribute:isochrone_geojson["properties"][isochrone_attribute]
                    for isochrone_attribute in
                    self.isochrones_attributes}
        pass